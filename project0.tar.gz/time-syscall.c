//This program measures the time taken to invoke the system call getpid() 100,000 times

#include <stdlib.h>
#include <stdio.h>

int main(char argc, char** argv){
   struct timeval start;
   struct timeval end;
   
   gettimeofday(&start,0); 
   int i;
   for(i=0;i<100000;i++){
	getpid();	
   }
   gettimeofday(&end,0);
   
   long elapsed_time_u = (end.tv_sec-start.tv_sec)*1000000 + (end.tv_usec-start.tv_usec);

   float syscall_avg = (double)elapsed_time_u/1000/100000;
   printf("Syscalls Performed: %d\n",i);
   printf("Total Elapsed Time: %f ms\n",(double)elapsed_time_u/1000);
   printf("Average Time Per Syscall: %f ms\n",syscall_avg); 

   return 0;	
}
