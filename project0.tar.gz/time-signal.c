// This program measures the time taken to handle an exeption and invoke a signal handler 100,000 times

#include <signal.h>
#include <time.h>
#include <stdio.h>
#include <stdlib.h>

//The signal hangler needs to detect that the number of times the method was invoked hits 100,000
//Report the results and then terminate the program.


//Use global variables for the start and end of the program.
struct timeval start;
struct timeval end;

void handle_sigfpe(int signum){
	static int sigfpe_counter = 0;
	//Handler code goes here
	
	sigfpe_counter++;

	if(sigfpe_counter == 100000){
		//elapsed time in ms
		gettimeofday(&end,0);
		long elapsed_time_u = (end.tv_sec-start.tv_sec)*1000000+(end.tv_usec-start.tv_usec);
		double avg_exc_time = (double)elapsed_time_u/1000/100000;
		printf("Exceptions Occurred: %d\n",sigfpe_counter);
		printf("Total Elapsed Time: %f ms\n",(double)elapsed_time_u/1000);
		printf("Average Time Per Exception: %f ms\n",avg_exc_time);
		//Exit the program
		exit(1);
	}

}

int main(char argc, char** argv){

   int x = 5;
   int y = 0;
   int z = 0;

   gettimeofday(&start,0);
   signal(SIGFPE,handle_sigfpe);

   z = x/y; //Causes SIGFPE 

   return 0;
}

