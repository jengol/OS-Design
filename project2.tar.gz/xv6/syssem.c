#include "types.h"
#include "param.h"
#include "defs.h"
#include "sem.h"

struct semaphore semtbl[NSEM];

void init_semtbl(void)
{
    int i;
    for (i = 0; i < NSEM; ++i) {
        semtbl[i].active = 0;
        initlock(&semtbl[i].lock, "sem lock");
        semtbl[i].value = 0;
    }
    return;
}

int sys_sem_init(void)
{
    int semid, n;
    argint(0, &semid);
    argint(1, &n);
    if (semid < 0 || semid >= NSEM)
        return -1;
    if (n < 0)
        return -1;
    struct semaphore *sem = &semtbl[semid];
    acquire(&sem->lock);
    if (sem->active) {
        release(&sem->lock);
        return -1;
    }
    sem->active = 1;
    sem->value = n;
    release(&sem->lock);
    return 0;
}

int sys_sem_destroy(void)
{
    int semid;
    argint(0, &semid);
    if (semid < 0 || semid >= NSEM)
        return -1;
    struct semaphore *sem = &semtbl[semid];
    acquire(&sem->lock);
    if (!sem->active) {
        release(&sem->lock);
        return -1;
    }
    sem->active = 0;
    release(&sem->lock);
    return 0;
}

int sys_sem_wait(void)
{
    int semid;
    argint(0, &semid);
    if (semid < 0 || semid >= NSEM)
        return -1;
    struct semaphore *sem = &semtbl[semid];
    acquire(&sem->lock);
    if (!sem->active) {
        release(&sem->lock);
        return -1;
    }
    while (sem->value < 1) {
        sleep(sem, &sem->lock);
    }
    sem->value--;
    release(&sem->lock);
    return 0;
}

int sys_sem_signal(void)
{
    int semid;
    argint(0, &semid);
    if (semid < 0 || semid >= NSEM)
        return -1;
    struct semaphore *sem = &semtbl[semid];
    acquire(&sem->lock);
    sem->value++;
    if (sem->value == 1)
        wakeup(sem);
    release(&sem->lock);
    return 0;
}