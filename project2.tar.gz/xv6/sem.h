#include "spinlock.h"

struct semaphore {
    int value;
    int active;
    struct spinlock lock;
};